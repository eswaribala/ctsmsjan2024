package com.cts.bankingaccountapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingaccountapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingaccountapiApplication.class, args);
	}

}
