package com.cts.bankingaccountapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingaccountapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
