package com.cts.jwtapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtapiApplication.class, args);
	}

}
