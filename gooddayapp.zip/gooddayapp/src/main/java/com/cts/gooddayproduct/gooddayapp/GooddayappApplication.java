package com.cts.gooddayproduct.gooddayapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GooddayappApplication {

	public static void main(String[] args) {
		SpringApplication.run(GooddayappApplication.class, args);
	}

}
