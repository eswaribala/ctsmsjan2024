package com.cts.gooddayproduct.gooddayapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GooddayappApplicationTests {

	@Test
	void contextLoads() {
	}

}
